<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <!--<h1 class="page-title">PIXEL</h1>-->
    <img src="<?php echo e(asset('images/Logo Piccel.png')); ?>" class="logo logo-stroke">
</div>
<div class="card panel p-3">
    <div class="card-body">
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <b>Sukses:</b> <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php
            use App\DetailSiswa;
            $biodata = DetailSiswa::where('id_user',Auth::user()->id)->first();
        ?>
        <h5 class="text-center">Biodata Diri</h5>
        <ul class="list-group list-group-flush text-left">
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nama Siswa </b></div><div class="col-9"> : <?php echo e($biodata->nama); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Kelas </b></div><div class="col-9"> : <?php echo e($biodata->kelas); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Jenis Kelamin </b></div><div class="col-9"> : <?php echo e($biodata->jenis_kelamin); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Tanggal Lahir </b></div><div class="col-9"> : <?php echo e($biodata->tgl_lahir); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Cita Cita </b></div><div class="col-9"> : <?php echo e($biodata->cita_cita); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Minat Melanjutkan </b></div><div class="col-9"> : <?php echo e($biodata->minat_melanjutkan); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Hobi </b></div><div class="col-9"> : <?php echo e($biodata->hobi); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nomor HP </b></div><div class="col-9"> : <?php echo e($biodata->no_telp); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Email </b></div><div class="col-9"> : <?php echo e($biodata->email); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Akun Facebook </b></div><div class="col-9"> : <?php echo e($biodata->facebook); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Akun Instagram </b></div><div class="col-9"> : <?php echo e($biodata->instagram); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Akun Youtube </b></div><div class="col-9"> : <?php echo e($biodata->youtube); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Kelebihan Diri </b></div><div class="col-9"> : <?php echo e($biodata->strength); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Kekurangan Diri </b></div><div class="col-9"> : <?php echo e($biodata->weakness); ?></div></div></li>
        </ul>
        <h5 class="text-center mt-5">Biodata Orang Tua</h5>
        <ul class="list-group list-group-flush text-left">
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nama Ayah </b></div><div class="col-9"> : <?php echo e($biodata->nama_ayah); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nomor HP Ayah </b></div><div class="col-9"> : <?php echo e($biodata->hp_ayah); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Pekerjaan Ayah </b></div><div class="col-9"> : <?php echo e($biodata->job_ayah); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nama Ibu </b></div><div class="col-9"> : <?php echo e($biodata->nama_ibu); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Nomor HP Ibu </b></div><div class="col-9"> : <?php echo e($biodata->hp_ibu); ?></div></div></li>
          <li class="list-group-item"><div class="row"><div class="col-3"><b>Pekerjaan Ibu </b></div><div class="col-9"> : <?php echo e($biodata->job_ibu); ?></div></div></li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/users/general/biodata_read.blade.php ENDPATH**/ ?>