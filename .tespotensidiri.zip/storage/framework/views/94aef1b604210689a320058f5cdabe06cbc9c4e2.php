<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom_user.css')); ?>">

    <title>IPI Talent Mapping</title>
  </head>
  <body class="container h-100">
    <div class="wrapper">
        <!-- <h1 class="page-title">Hello, world!</h1> -->
        <div class="text-center mb-4">
            <img src="<?php echo e(asset('images/Asset 7@4x.png')); ?>" class="logo">
        </div>
        <div class="card panel login-box p-3">
            <div class="card-body">
                <h2 class="box-title">Member Area</h2>
                <div class="md-form  input-with-post-icon">
                    <i class="fas fa-key input-prefix"></i>
                    <input type="text" id="kode_sekolah" class="form-control">
                    <label for="kode_sekolah">Kode Sekolah</label>
                    <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
                </div>
            </div>
        </div> 
    </div>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
  </body>
</html><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/welcome.blade.php ENDPATH**/ ?>