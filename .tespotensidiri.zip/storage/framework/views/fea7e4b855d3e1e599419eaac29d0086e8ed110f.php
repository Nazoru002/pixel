<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <!--<h1 class="page-title">PIXEL</h1>-->
    <img src="<?php echo e(asset('images/Logo Piccel.png')); ?>" class="logo logo-stroke">
</div>
<div class="card panel p-3 mb-5">
    <div class="card-body">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger text-left">
                <b>Terdapat Error pada pengisian formulir : </b>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <h4 style="font-weight: bolder;">Biodata Diri</h4>
        <form action="<?php echo e(route('siswa-biodata')); ?>" method="POST" class="form-biodata">
            <?php echo csrf_field(); ?>
            <div class="form-group md-form">
                <input type="text"class="form-control" name="nama" id="nama" value="<?php echo e(old('nama')); ?>" required>
                <label for="nama">Nama Lengkap <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="text"class="form-control" name="kelas" id="kelas" value="<?php echo e(old('kelas')); ?>" required>
                <label for="kelas">Asal Kelas <span class="text-red">*)</span></label>
            </div>
            <div class="form-group text-left">
                <label>Jenis Kelamin <span class="text-red">*)</span></label>
                <br>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="defaultInline1" name="jenis_kelamin" required value="Laki-Laki" <?php echo e(((old('jenis_kelamin') == 'Laki-Laki')?'selected':'')); ?>>
                    <label class="custom-control-label" for="defaultInline1">Laki-Laki</label>
                </div>

                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="defaultInline2" name="jenis_kelamin" required value="Perempuan" <?php echo e(((old('jenis_kelamin') == 'Perempuan')?'selected':'')); ?>>
                    <label class="custom-control-label" for="defaultInline2">Perempuan</label>
                </div>
            </div>
            <div class="form-group md-form">
                <input type="text"class="form-control" name="no_telp" value="<?php echo e(old('no_telp')); ?>" id="no_hp" required>
                <label for="no_hp">Nomor HP <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="date"class="form-control" name="tgl_lahir" value="<?php echo e(old('tgl_lahir')); ?>" id="date" required>
                <label for="date">Tanggal Lahir <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <textarea class="form-control md-textarea" id="alamat" name="alamat" required><?php echo e(old('alamat')); ?></textarea>
                <label for="alamat">Alamat Rumah <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="email" class="form-control" id="email"  value="<?php echo e(old('email')); ?>"name="email" required>
                <label for="email">Email <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="fb" value="<?php echo e(old('facebook')); ?>" name="facebook">
                <label for="fb">Akun Facebook</label>
            </div>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="ig" value="<?php echo e(old('instagram')); ?>" name="instagram">
                <label for="ig">Akun Instagram</label>
            </div>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="yt" value="<?php echo e(old('youtube')); ?>" name="youtube">
                <label for="yt">Channel Youtube</label>
            </div>
            <div class="form-group text-left" style="position: relative;">
                <label for="ct">Cita-Cita <span class="text-red">*)</span></label>
                <select id="ct" class="custom-select" name="cita_cita">
                    <option value="Pegawai Kantoran" 
                    <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'Pegawai Kantoran')?'selected':''):'selected')); ?>>Pegawai Kantoran</option>
                    <option value="Programmer" <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'Programmer')?'selected':''):'')); ?>>Programmer</option>
                    <option value="Merakit Komputer"
                    <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'Merakit Komputer')?'selected':''):'')); ?>>Merakit Komputer</option>
                    <option value="Jalan-Jalan Keliling Dunia"
                    <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'Jalan-Jalan Keliling Dunia')?'selected':''):'')); ?>>Jalan-Jalan Keliling Dunia</option>
                    <option value="Photographer"
                    <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'Photographer')?'selected':''):'')); ?>>Photographer</option>
                    <option value="other"
                    <?php echo e(((null !== old('cita_cita'))? ((old('cita_cita') == 'other')?'selected':''):'')); ?>>Lainnya... Sebutkan :</option>
                </select>
            </div>
            <div id="ctOther" class="form-group md-form" style="display:none;">
                <input type="text" class="form-control" id="ct2">
                <label for="ct2">Sebutkan Cita-Cita <span class="text-red">*)</span></label>
            </div>
            <div class="form-group text-left" style="position: relative;">
                <label for="hb">Hobi <span class="text-red">*)</span></label>
                <select id="hb" class="custom-select" name="hobi">
                    <option value="K-Pop" 
                    <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'K-Pop')?'selected':''):'selected')); ?>>K-Pop</option>
                    <option value="Olah Raga" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Olah Raga')?'selected':''):'')); ?>>Olah Raga</option>
                    <option value="Esport (Game Online)" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Esport (Game Online)')?'selected':''):'')); ?>>Esport (Game Online)</option>
                    <option value="Youtuber" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Youtuber')?'selected':''):'')); ?>>Youtuber</option>
                    <option value="Bahasa Inggris" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Bahasa Inggris')?'selected':''):'')); ?>>Bahasa Inggris</option>
                    <option value="Music" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Music')?'selected':''):'')); ?>>Music</option>
                    <option value="Nonton Film" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Nonton Film')?'selected':''):'')); ?>>Nonton Film</option>
                    <option value="Photographer" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Photographer')?'selected':''):'')); ?>>Photographer</option>
                    <option value="Menggambar" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Menggambar')?'selected':''):'')); ?>>Menggambar</option>
                    <option value="other" <?php echo e(((null !== old('hobi'))? ((old('hobi') == 'Other')?'selected':''):'')); ?>>Lainnya... Sebutkan:</option>
                </select>
            </div>
            <div id="hbOther" class="form-group md-form"  style="display:none;">
                <input type="text" class="form-control" id="hb2">
                <label for="hb2">Sebutkan Hobi <span class="text-red">*)</span></label>
            </div>
            <div class="form-group text-left">
                <label>Minat Melanjutkan <span class="text-red">*)</span></label>
                <br>
                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="minat1" name="minat_melanjutkan" required value="SMA" <?php echo e(((old('minat_melanjutkan') == 'SMA')?'selected':'')); ?>>
                    <label class="custom-control-label" for="minat1">SMA</label>
                </div>

                <div class="custom-control custom-radio custom-control-inline">
                    <input type="radio" class="custom-control-input" id="minat2" name="minat_melanjutkan" required value="SMK" <?php echo e(((old('minat_melanjutkan') == 'SMK')?'selected':'')); ?>>
                    <label class="custom-control-label" for="minat2">SMK</label>
                </div>
            </div>
            <div class="form-group md-form">
                <textarea class="form-control md-textarea" id="strength" name="strength" required><?php echo e(old('strength')); ?></textarea>
                <label for="strength">Menurutmu Apa kelebihan dirimu ? <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <textarea class="form-control md-textarea" id="weakness" name="weakness" required><?php echo e(old('weakness')); ?></textarea>
                <label for="weakness">Menurutmu Apa kekurangan dirimu ? <span class="text-red">*)</span></label>
            </div>
            <h4 style="font-weight: bolder;">Biodata Orang Tua</h4>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="nayah" value="<?php echo e(old('nama_ayah')); ?>" required name="nama_ayah">
                <label for="nayah">Nama Ayah <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="nhpayah" value="<?php echo e(old('hp_ayah')); ?>" required name="hp_ayah">
                <label for="nhpayah">No. HP Ayah <span class="text-red">*)</span></label>
            </div>
            <div class="form-group text-left" style="position: relative;">
                <label for="jayah">Pekerjaan Ayah <span class="text-red">*)</span></label>
                <select id="jayah" class="custom-select" name="job_ayah">
                    <option value="Pegawai Negeri/TNI/POLRI/BUMN/BUMD" selected>Pegawai Negeri/TNI/POLRI/BUMN/BUMD</option>
                    <option value="Pegawai Swasta">Pegawai Swasta</option>
                    <option value="Wiraswasta/Pengusaha/Pedagang">Wiraswasta/Pengusaha/Pedagang</option>
                    <option value="other">Lainnya... Sebutkan:</option>
                </select>
            </div>
            <div id="jayahOther" class="form-group md-form" style="display:none;">
                <input type="text" class="form-control" id="jayah2">
                <label for="jayah2">Sebutkan Pekerjaan Ayah <span class="text-red">*)</span></label>
            </div>


            <div class="form-group md-form">
                <input type="text" class="form-control" id="nibu" value="<?php echo e(old('nama_ibu')); ?>" required name="nama_ibu">
                <label for="nibu">Nama Ibu <span class="text-red">*)</span></label>
            </div>
            <div class="form-group md-form">
                <input type="text" class="form-control" id="nhpibu" value="<?php echo e(old('hp_ibu')); ?>" required name="hp_ibu">
                <label for="nhpibu">No. HP Ibu <span class="text-red">*)</span></label>
            </div>
            <div class="form-group text-left" style="position: relative;">
                <label for="jibu">Pekerjaan Ibu <span class="text-red">*)</span></label>
                <select id="jibu" class="custom-select" name="job_ibu">
                    <option value="Ibu Rumah Tangga" selected>Ibu Rumah Tangga</option>
                    <option value="Pegawai Negeri/TNI/POLRI/BUMN/BUMD">Pegawai Negeri/TNI/POLRI/BUMN/BUMD</option>
                    <option value="Pegawai Swasta">Pegawai Swasta</option>
                    <option value="Wiraswasta/Pengusaha/Pedagang">Wiraswasta/Pengusaha/Pedagang</option>
                    <option value="other">Lainnya... Sebutkan:</option>
                </select>
            </div>
            <div id="jayahOther" class="form-group md-form" style="display:none;">
                <input type="text" class="form-control" id="jibu2">
                <label for="jibu2">Sebutkan Pekerjaan Ibu <span class="text-red">*)</span></label>
            </div>
            <div class="">
                <button type="submit" class="btn btn-block btn-rounded btn-primary"><b>Submit</b></button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
<script type="text/javascript">
    $(document).ready(function(){

    });
    $('#ct').on('change',function(){
        var selection = $(this).val();
        switch(selection){
            case "other":
                $(this).removeAttr('name');
                $(this).removeAttr('required');
                $('#ctOther').show();
                $('#ct2').attr('name','cita_cita');
                $('#ct2').attr('required',true);
            break;
            default:
                $("#ctOther").hide();
                $(this).attr('name','cita_cita');
                $(this).attr('required',true);
                $('#ct2').removeAttr('name');
                $('#ct2').removeAttr('required');
        }
    });
    $('#hb').on('change',function(){
        var selection = $(this).val();
        switch(selection){
            case "other":
                $(this).removeAttr('name');
                $(this).removeAttr('required');
                $('#hbOther').show();
                $('#hb2').attr('name','hobi');
                $('#hb2').attr('required',true);
            break;
            default:
                $("#hbOther").hide();
                $(this).attr('name','hobi');
                $(this).attr('required',true);
                $('#hb2').removeAttr('name');
                $('#hb2').removeAttr('required');
        }
    });
    $('#jayah').on('change',function(){
        var selection = $(this).val();
        switch(selection){
            case "other":
                $(this).removeAttr('name');
                $(this).removeAttr('required');
                $('#jayahOther').show();
                $('#jayah2').attr('name','job_ayah');
                $('#jayah2').attr('required',true);
            break;
            default:
                $("#jayahOther").hide();
                $(this).attr('name','job_ayah');
                $(this).attr('required',true);
                $('#jayah2').removeAttr('name');
                $('#jayah2').removeAttr('required');
        }
    });
    $('#jibu').on('change',function(){
        var selection = $(this).val();
        switch(selection){
            case "other":
                $(this).removeAttr('name');
                $(this).removeAttr('required');
                $('#jibuOther').show();
                $('#jibu2').attr('name','job_ibu');
                $('#jibu2').attr('required',true);
            break;
            default:
                $("#jibuOther").hide();
                $(this).attr('name','job_ibu');
                $(this).attr('required',true);
                $('#jibu2').removeAttr('name');
                $('#jibu2').removeAttr('required');
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5777787/public_html/tespotensidiri-epic/resources/views/users/general/biodata_siswa.blade.php ENDPATH**/ ?>