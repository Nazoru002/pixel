<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <img src="<?php echo e(asset('images/Asset 7@4x.png')); ?>" class="logo">
    <div class="w-100">
        <h5 class="logo-tagline">Jaminan Kerja</h5>
    </div>
</div>
<div class="card panel p-3">
    <div class="card-body">
        <?php
            use App\Sekolah;
            $data = Sekolah::find(session()->get('id_sekolah'));
        ?>
        <h3><b>SELAMAT DATANG</b><br> di website persiapan pemetaan potensi diri siswa/siswi <b><?php echo e($data->nama_sekolah); ?></b> kerjasama dengan International Professional Institute.</h3><br>
        <h3>Silahkan log-in terlebih dahulu sebelum melanjutkan</h3>
        <div class="form-grup text-center">
            <a href="<?php echo e(route('user-login')); ?>" class="btn btn-primary btn-rounded">Log-in</a>
            <a href="<?php echo e(url('logout')); ?>" class="btn btn-danger btn-rounded">Keluar</a>
        </div>
    </div>
</div> 
<div class="w-100 text-center mt-2">
    <h3 class="footer-tagline">Suksesmu Berawal Dari Sini!</h3>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/users/landing.blade.php ENDPATH**/ ?>