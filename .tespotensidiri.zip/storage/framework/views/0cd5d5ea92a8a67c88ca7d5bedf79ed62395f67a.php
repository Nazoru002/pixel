
<?php $__env->startSection('title',"Edit data Siswa"); ?>
<?php $__env->startSection('content'); ?>

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-12 mb-4">

          <!--Card-->
          <div class="card">

            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger" role="alert">
                <b>Error :</b> <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success" role="alert">
                <b>Sukses :</b> <?php echo e(session()->get('success')); ?>

              </div>
            <?php endif; ?>
            <div class="card-body">
              <form action="<?php echo e(route('admin-siswa-edit',$data->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                 <div class="form-group md-form">
                    <input type="text"class="form-control" name="nama_user" id="name" required value="<?php echo e($data->nama_user); ?>">
                    <label for="name">Nama Siswa</label>
                </div>
                <div class="form-group text-left" style="position: relative;">
                  <label for="as">Asal Sekolah</label>
                  <select id="as" class="custom-select" name="id_sekolah">
                    <?php
                      use App\Sekolah;
                      $sekolah = Sekolah::all();
                    ?>
                    <?php $__currentLoopData = $sekolah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($s->id); ?>" <?php echo e(($data->id_sekolah == $s->id)?'selected':''); ?>><?php echo e($s->nama_sekolah); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group md-form">
                    <input type="text"class="form-control" name="username" id="usn" required value="<?php echo e($data->username); ?>">
                    <label for="usn">Username </label>
                </div>
                <div class="form-group md-form">
                    <input type="text"class="form-control" name="password" id="pwd" required value="<?php echo e($data->display_password); ?>">
                    <label for="pwd">Password </label>
                </div>
                <button type="submit" class="btn btn-rounded btn-primary">Simpan</button>
                <a href="<?php echo e(route('admin-siswa')); ?>" class="btn btn-rounded btn-danger">Kembali</a>
              </form>
            </div>

          </div>
          <!--/.Card-->

        </div>

      </div>
      <!--Grid row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>

  <!-- Charts -->
  <script>

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/admin/siswa/edit.blade.php ENDPATH**/ ?>