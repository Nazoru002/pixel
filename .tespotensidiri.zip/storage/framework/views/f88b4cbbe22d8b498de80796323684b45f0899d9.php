<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <!--<h1 class="page-title">PIXEL</h1>-->
    <img src="<?php echo e(asset('images/Logo Piccel.png')); ?>" class="logo logo-stroke">
</div>
<div class="card panel p-3">
    <div class="card-body">
        <h5 class="mb-5" style="font-weight: bolder;">Selamat Datang, <?php echo e(Auth::user()->nama_user); ?></h5>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <b>Sukses:</b> <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php
            use App\JawabanTesUser;
            $cdone = 'green lighten-4';
            $numerik = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','numerik')->get();
            $bahasa = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','bahasa')->get();
            $logika = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','logika')->get();
            $kepribadian = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','kepribadian')->get();
            $dayaingat = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','daya_ingat')->get();
        ?>
        <div class="row tes-button-group">
            <div class="col-md-4 col-sm-4">
                <a href="<?php echo e(route('siswa-tes-numerik')); ?>" class="tes-link">
                    <div class="card tes-button <?php echo e((count($numerik) >= 10)?$cdone:''); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 2@4x.png')); ?>" class="tes-icon">
                            <p class="mt-2">Tes Numerik</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="<?php echo e(route('siswa-tes-bahasa')); ?>" class="tes-link">
                    <div class="card tes-button <?php echo e((count($bahasa) >= 10)?$cdone:''); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 1@4x.png')); ?>" class="tes-icon">
                            <p class="mt-2">Tes Bahasa</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="<?php echo e(route('siswa-tes-logika')); ?>" class="tes-link">
                    <div class="card tes-button <?php echo e((count($logika) >= 10)?$cdone:''); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 3@4x.png')); ?>" class="tes-icon">
                            <p class="mt-2">Tes Logika</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="<?php echo e(route('siswa-tes-dayaingat')); ?>" class="tes-link">
                    <div class="card tes-button <?php echo e((count($dayaingat) >= 10)?$cdone:''); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 4@4x.png')); ?>" class="tes-icon">
                            <p class="mt-2">Tes Daya Ingat</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="<?php echo e(route('siswa-tes-kepribadian')); ?>" class="tes-link">
                    <div class="card tes-button <?php echo e((count($kepribadian) >= 10)?$cdone:''); ?>">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 5@4x.png')); ?>" class="tes-icon">
                            <p class="mt-2">Tes Kepribadian</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-4">
                <a href="#" class="tes-link">
                    <div class="card tes-button">
                        <div class="card-body">
                            <img src="<?php echo e(asset('images/Asset 6@4x.png')); ?>" class="tes-icon">
                            <p>Coming Soon!</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="popupmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
    <div class="modal-content bg-transparent border-none">
      <div class="modal-body ">
        <button type="button" class="close text-white float-right" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        <br>
        <div id="popupcarousel" class="owl-carousel">
            <div class="p-3"><img src="<?php echo e(asset('images/POP_UP_APP_PSC.jpg')); ?>" class="img-responsive"></div>
            <div class="p-3"><img src="<?php echo e(asset('images/POP_UP_APP_SKOR.jpg')); ?>" class="img-responsive"></div>
            <div class="p-3"><img src="<?php echo e(asset('images/POP_UP_APP_SPIDER.jpg')); ?>" class="img-responsive"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_addon'); ?>
<script>
    var owl = $('#popupcarousel');
    owl.owlCarousel({
    animateOut: 'fadeOut',
    animateIn: 'fadeIn',
    items:1,
    loop:true,
    freeDrag:false,mouseDrag:false,touchDrag:false,pullDrag:false,autoplay:true,autoplayTimeout:5000});
    
    $(document).ready(function(){
        <?php if(!session()->has('first')): ?>
            $('#popupmodal').modal();
            <?php
                session()->put('first',true);
            ?>
        <?php endif; ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/users/general/index_siswa.blade.php ENDPATH**/ ?>