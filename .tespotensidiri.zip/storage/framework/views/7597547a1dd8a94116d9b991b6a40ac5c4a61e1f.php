
<?php $__env->startSection('title','Data Sekolah'); ?>
<?php $__env->startSection('content'); ?>

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-12 mb-4">

          <!--Card-->
          <div class="card">
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger" role="alert">
                <b>Error :</b> <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success" role="alert">
                <b>Sukses :</b> <?php echo e(session()->get('success')); ?>

              </div>
            <?php endif; ?>
            <!--Card content-->
            <div class="card-body">
              <a href="<?php echo e(route('admin-sekolah-create')); ?>" class="btn btn-rounded btn-primary">Tambah Data Sekolah</a>
              <?php
                use App\Sekolah;
                $data = Sekolah::with('rsiswaAll')->get();
              ?>
              <table id="data_sekolah" class="table table-striped table-bordered" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nama Sekolah</th>
                    <th>Jumlah Siswa</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($d->id); ?></td>
                      <td><?php echo e($d->nama_sekolah); ?></td>
                      <td><?php echo e($d->rsiswaAll()->count()); ?></td>
                      <td><a href="<?php echo e(route('admin-sekolah-detail',$d->id)); ?>" class="btn btn-rounded btn-primary mr-3">Lihat Grafik</a><a href="<?php echo e(route('admin-sekolah-edit',$d->id)); ?>" class="btn btn-rounded btn-warning mr-3">Edit</a><button href="#" class="btn btn-rounded btn-danger btn-delete" data-url="<?php echo e(route('admin-sekolah-delete',$d->id)); ?>">Hapus</button></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <th> Tidak ada data</th>
                      <th> Tidak ada data</th>
                      <th> Tidak ada data</th>
                      <th> Tidak ada data</th>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

          </div>
          <!--/.Card-->

        </div>

      </div>
      <!--Grid row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>

  <!-- Charts -->
  <script>
    $('.btn-delete').on('click',function(){
      var url = $(this).data('url');
      Swal.fire({
          title: 'Anda yakin ingin menghapus data siswa ini ?',
          text: "Semua data yang terkait dengan sekolah ini akan ikut terhapus!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#ff4444',
          confirmButtonText: 'Hapus',
      }).then((result) => {
          if (result.value) {
            window.location.href = url;
          }
      });
    });
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/admin/sekolah/index.blade.php ENDPATH**/ ?>