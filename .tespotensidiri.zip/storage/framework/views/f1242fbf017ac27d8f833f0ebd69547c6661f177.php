<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom_user.css?v=1.0')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/assets/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Chart.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/Myriad/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css">
    <title><?php echo $__env->yieldContent('title'); ?> IPI Talent Mapping</title>
    <style>
        .text-icon{
            font-size: 13px;
        }
    </style>
  </head>
  <body class="h-100">
    <div class="main-wrapper">
        <div id="content" class="wrapper">
            <?php $__env->startSection('content'); ?>
    
            <?php echo $__env->yieldSection(); ?>
        </div>
    </div>
    <?php if(url()->current() != route('index') && url()->current() != route('landing') && url()->current() != route('user-login') && url()->current() != route('siswa-biodata') ): ?>
    <div class="mt-5">&nbsp;</div>
    <div class="row w-100">
        <div class="col">
            <div class="mt-5">&nbsp;</div>
            <div class="mt-5">&nbsp;</div>
        </div>
        <div class="col">
            <div class="fixed-bottom w-100 pt-3 white text-center text-grey d-flex justify-content-center px-3">
                <div class="row">
                    <div class="col-md-2 col-4">
                        <a href="<?php echo e(route('siswa-index')); ?>" class="py-1 px-1 bot-nav-link w-100">
                            <i class="fas fa-home fa-md"></i><br><p class="text-icon">Beranda</p>
                        </a>
                    </div>
                    <div class="col-md-2 col-4 mx-md-3">
                        <a href="<?php echo e(route('siswa-tes-hasil')); ?>" class="py-1 px-1 bot-nav-link w-100">
                            <i class="fas fa-clipboard-list fa-md"></i><br><p class="text-icon">Hasil Tes</p>
                        </a>
                    </div>
                    <div class="col-md-2 col-4">
                        <a href="<?php echo e(route('siswa-read-biodata')); ?>" class="py-1 px-1 bot-nav-link w-100">
                            <i class="fas fa-user fa-md"></i><br><p class="text-icon">Biodata</p>
                        </a>
                    </div>
                    <div class="col-md-2 col-6 mx-md-3">
                        <a href="<?php echo e(route('siswa-settings')); ?>" class="py-1 px-1 bot-nav-link w-100">
                            <i class="fas fa-cogs fa-md"></i><br><p class="text-icon">Pengaturan</p>
                        </a>
                    </div>
                    <div class="col-md-2 col-6">
                        <a href="<?php echo e(url('logout')); ?>" class="py-1 px-1 bot-nav-link w-100">
                            <i class="fas fa-power-off fa-md"></i><br><p class="text-icon">Logout</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/animatedModal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript">
    
        $(document).ready(function () {
            if($(window).width() > 767){
            }
            $("#sidebar").mCustomScrollbar({
                 theme: "minimal"
            });
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                
                // close dropdowns
                $('.collapse.in').toggleClass('in');
                // and also adjust aria-expanded attributes we use for the open/closed arrows
                // in our CSS
                $('a[aria-expanded=true]').attr('aria-expanded', 'false');
            });
        });
    </script>
    <?php $__env->startSection('js_addon'); ?>

    <?php echo $__env->yieldSection(); ?>
  </body>
</html><?php /**PATH /home/u5777787/public_html/tespotensidiri/resources/views/users/layouts/master2.blade.php ENDPATH**/ ?>