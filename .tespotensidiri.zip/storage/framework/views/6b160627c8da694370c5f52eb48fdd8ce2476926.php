<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css"/>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom_user.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/assets/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/assets/owl.theme.default.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/Chart.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('fonts/Myriad/style.css')); ?>">

    <title><?php echo $__env->yieldContent('title'); ?> IPI Talent Mapping</title>
  </head>
  <body class="h-100">
    <div class="wrapper">
        <?php $__env->startSection('content'); ?>

        <?php echo $__env->yieldSection(); ?>
    </div>
    <div class="mb-5 mt-5"> &nbsp;</div>
    <?php if(url()->current() != route('index') && url()->current() != route('landing') && url()->current() != route('user-login') && url()->current() != route('siswa-biodata') ): ?>
    <div class="fixed-bottom w-100 pt-3 white text-center text-grey d-flex justify-content-center">
        <a href="<?php echo e(route('siswa-index')); ?>" class="py-1 px-3 bot-nav-link">
            <i class="fas fa-home fa-lg"></i><br><p>Beranda</p>
        </a>
        <a href="<?php echo e(route('siswa-tes-hasil')); ?>" class="py-1 px-3 bot-nav-link">
            <i class="fas fa-clipboard-list fa-lg"></i><br><p>Hasil Tes</p>
        </a>
        <a href="<?php echo e(route('siswa-read-biodata')); ?>" class="py-1 px-3 bot-nav-link">
            <i class="fas fa-user fa-lg"></i><br><p>Biodata-ku</p>
        </a>
        <a href="<?php echo e(url('logout')); ?>" class="py-1 px-3 bot-nav-link">
            <i class="fas fa-power-off fa-lg"></i><br><p>Logout</p>
        </a>
    </div>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/Chart.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/animatedModal.min.js')); ?>"></script>
    <?php $__env->startSection('js_addon'); ?>

    <?php echo $__env->yieldSection(); ?>
  </body>
</html><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/users/layouts/master.blade.php ENDPATH**/ ?>