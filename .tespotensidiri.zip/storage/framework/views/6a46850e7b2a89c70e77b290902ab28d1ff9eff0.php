
<?php $__env->startSection('title',"Pengaturan"); ?>
<?php $__env->startSection('content'); ?>

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-12 mb-4">

          <!--Card-->
          <div class="card">
            
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger" role="alert">
                <b>Error :</b> <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success" role="alert">
                <b>Sukses :</b> <?php echo e(session()->get('success')); ?>

              </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger text-left">
                    <b>Terdapat Error pada pengisian formulir : </b>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card-body">
                <h4 class="text-left">Ganti Password</h4>
                <form action="<?php echo e(route('bk-settings')); ?>" method="POST" class="mb-4">
                    <?php echo csrf_field(); ?>
                    <div class="md-form input-with-post-icon">
                        <input type="password" id="password" class="form-control" name="password_lama" required>
                        <label for="password">Password Lama</label>
                        <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
                    </div>
                    <div class="md-form input-with-post-icon">
                        <input type="password" id="password" class="form-control" name="password_baru" required>
                        <label for="password">Password Baru</label>
                        <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
                    </div>
                    <div class="md-form input-with-post-icon">
                        <input type="password" id="password" class="form-control" name="konfirmasi_password_baru" required>
                        <label for="password">Konfirmasi Password Baru</label>
                        <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
                    </div>
                    <button type="submit" class="btn btn-primary btn-rounded waves-effect waves-light btn-block">Rubah</button>
                </form>
                <hr>
                <h4 class="text-left">Ganti Nama Akun</h4>
                <form action="<?php echo e(route('bk-settings-name')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="md-form">
                        <input type="text" name="nama_user" class="form-control" required value="<?php echo e(Auth::user()->nama_user); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary btn-rounded btn-block">Rubah</button>
                </form>
            </div>

          </div>
          <!--/.Card-->

        </div>

      </div>
      <!--Grid row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>

  <!-- Charts -->
  <script>

  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('bk.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5777787/public_html/tespotensidiri/resources/views/bk/settings.blade.php ENDPATH**/ ?>