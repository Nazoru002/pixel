<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <h1 class="page-title">PIXEL</h1>
</div>
<div class="card panel login-box p-3">
    <div class="card-body">
        <h2 class="box-title">Tes Daya Ingat</h2>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success">
                <b>Sukses:</b> <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php
            use App\JawabanTesUser;
            $data = JawabanTesUser::where('id_user',Auth::user()->id)->where('type','daya_ingat')->with('rkunci')->get();
        ?>
        <div class="bold text-left">
            <ul>
                <li>Tujuan Tes : Tes ini diperuntukan untuk mengetahui kemampuan daya ingat anda</li>
                <li>Jumlah Soal : 10 Soal</li>
                <?php if(count($data) > 0): ?>
                    <li>Status Pengerjaan : <span class="text-success">Sudah Selesai</span></li>
                <?php else: ?>
                    <li>Status Pengerjaan : <span class="text-danger">Belum Selesai</span></li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="text-center bold">
            <?php if(count($data) < 1): ?>
                <a href="<?php echo e(route('siswa-tes-dayaingat-start')); ?>" class="btn btn-rounded btn-primary">Mulai</a>
            <?php endif; ?>
            <a href="<?php echo e(route('siswa-index')); ?>" class="btn btn-rounded btn-danger">Halaman Utama</a>
        </div>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\xampp\htdocs\TalentMapping\resources\views/users/tes/dayaingat.blade.php ENDPATH**/ ?>