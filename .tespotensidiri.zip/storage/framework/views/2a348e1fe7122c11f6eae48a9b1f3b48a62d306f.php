
<?php $__env->startSection('title','Data Siswa'); ?>
<?php $__env->startSection('content'); ?>

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-12 mb-4">

          <!--Card-->
          <div class="card">
            <?php if(session()->has('error')): ?>
              <div class="alert alert-danger" role="alert">
                <b>Error :</b> <?php echo e(session()->get('error')); ?>

              </div>
            <?php endif; ?>
            <?php if(session()->has('success')): ?>
              <div class="alert alert-success" role="alert">
                <b>Sukses :</b> <?php echo e(session()->get('success')); ?>

              </div>
            <?php endif; ?>
            <!--Card content-->
            <div class="card-body">
                <div class="row">
                    <div class="col mb-1"><a href="<?php echo e(route('admin-siswa-create')); ?>" class="btn btn-rounded btn-primary btn-block">Tambah Data Siswa</a></div>
                    <div class="col mb-1"><a href="<?php echo e(route('admin-siswa-export')); ?>" class="btn btn-info btn-rounded btn-block">Export Biodata Siswa</a></div>
                    <div class="col mb-1"><a href="<?php echo e(route('admin-siswa-export2')); ?>" class="btn btn-success btn-rounded btn-block">Export Username Siswa</a></div>
                    <div class="col mb-1"><a href="<?php echo e(route('admin-hasilTes-export')); ?>" class="btn btn-rounded btn-warning mr-3 btn-block">Export Hasil Tes Siswa</a></div>
                </div>
              <?php
                use App\User;
                $data = User::where('level','siswa')->orderBy('updated_at','DESC')->with('rsekolah')->paginate(40);
              ?>
              <table id="data_siswa" class="table table-striped table-bordered table-responsive-md" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nama Siswa</th>
                    <th>Asal Sekolah</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($d->id); ?></td>
                      <td><?php echo e($d->nama_user); ?></td>
                      <td><?php echo e($d->rsekolah->nama_sekolah); ?></td>
                      <td><a href="<?php echo e(route('admin-siswa-detail',$d->id)); ?>" class="btn btn-rounded btn-primary mr-3">Lihat Detail</a><a href="<?php echo e(route('admin-siswa-edit',$d->id)); ?>" class="btn btn-rounded btn-warning mr-3">Edit</a><button href="#" class="btn btn-rounded btn-danger btn-delete" data-url="<?php echo e(route('admin-siswa-delete',$d->id)); ?>">Hapus</button></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <th> Tidak ada data</th>
                      <th> Tidak ada data</th>
                      <th> Tidak ada data</th>
                    </tr>
                  <?php endif; ?>
                </tbody>
              </table>
              <div class="d-flex justify-content-center">
                <?php echo e($data->onEachSide(0)->links()); ?>

              </div>
            </div>

          </div>
          <!--/.Card-->

        </div>

      </div>
      <!--Grid row-->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
  <script type="text/javascript">
    // Animations initialization
    new WOW().init();

  </script>

  <!-- Charts -->
  <script>
    $('.btn-delete').on('click',function(){
      var url = $(this).data('url');
      Swal.fire({
          title: 'Anda yakin ingin menghapus data siswa ini ?',
          text: "Data Siswa termasuk Tes dan Biodata Siswa akan ikut terhapus!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#ff4444',
          confirmButtonText: 'Hapus',
      }).then((result) => {
          if (result.value) {
            window.location.href = url;
          }
      });
    });
  </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5777787/public_html/tespotensidiri/resources/views/admin/siswa/index.blade.php ENDPATH**/ ?>