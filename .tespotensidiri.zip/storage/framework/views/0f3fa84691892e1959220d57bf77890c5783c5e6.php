<?php $__env->startSection('content'); ?>
<div class="card panel login-box p-3">
    <div class="card-body">
        <h2 class="box-title">Admin Area</h2>
        <?php if(session()->has('error')): ?>
            <div class="alert alert-danger text-left" role="alert">
                <b>Error</b> : <?php echo e(session()->get('error')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin-login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="md-form  input-with-post-icon">
                <i class="fas fa-user input-prefix"></i>
                <input type="text" id="username" class="form-control" name="username">
                <label for="username">Username</label>
                <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
            </div>
            <div class="md-form  input-with-post-icon">
                <i class="fas fa-lock input-prefix"></i>
                <input type="password" id="password" class="form-control" name="password">
                <label for="password">Password</label>
                <!-- <small class="form-text text-muted">Masukan kode sekolah dikolom ini</small> -->
            </div>
            <button type="submit" class="btn btn-primary btn-rounded waves-effect waves-light btn-block">Masuk</button>
        </form>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5777787/public_html/tespotensidiri-epic/resources/views/admin/login.blade.php ENDPATH**/ ?>