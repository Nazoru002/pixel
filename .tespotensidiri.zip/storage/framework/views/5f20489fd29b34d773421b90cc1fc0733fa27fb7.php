<?php $__env->startSection('content'); ?>
<div class="text-center mb-4">
    <!--<h1 class="page-title">PIXEL</h1>-->
    <img src="<?php echo e(asset('images/Logo Piccel.png')); ?>" class="logo logo-stroke">
</div>
<div class="card panel p-3">
    <form action="<?php echo e(route('siswa-biodata-edit')); ?>" method="POST">
    <?php echo csrf_field(); ?>
        <div class="card-body">
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <b>Sukses:</b> <?php echo e(session()->get('success')); ?>

                </div>
            <?php endif; ?>
            <?php
                use App\DetailSiswa;
                $biodata = DetailSiswa::where('id_user',Auth::user()->id)->first();
            ?>
            <h5 class="text-center">Biodata Diri</h5>
            <ul class="list-group list-group-flush text-left">
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nama Siswa </b> <a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e(implode(explode(' ', $biodata->nama),'-')); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e(implode(explode(' ', $biodata->nama),'-')); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="nama" value="<?php echo e($biodata->nama); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->nama); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item"><div class="row"><div class="col-3"><b>Lembaga Sekolah </b></div><div class="col-9"> : <?php echo e($biodata->lembaga_sekolah); ?></div></div></li>
                <li class="list-group-item"><div class="row"><div class="col-3"><b>Kelas </b></div><div class="col-9"> : <?php echo e($biodata->kelas); ?></div></div></li>
                <li class="list-group-item"><div class="row"><div class="col-3"><b>Jurusan </b></div><div class="col-9"> : <?php echo e($biodata->jurusan); ?></div></div></li>
                <li class="list-group-item"><div class="row"><div class="col-3"><b>Sub Jurusan </b></div><div class="col-9"> : <?php echo e($biodata->jurusan); ?>-<?php echo e($biodata->sub_jurusan); ?></div></div></li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Jenis Kelamin </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->jenis_kelamin); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->jenis_kelamin); ?>">
                            <div class="d-none input-group text-left m-0" style="position: relative;">
                                 : &nbsp;<select class="custom-select" name="jenis_kelamin">
                                    <option value="Laki-Laki" <?php echo e((($biodata->jenis_kelamin == 'Laki-Laki')?'selected':'')); ?>>Laki-Laki</option>
                                    <option value="Perempuan" <?php echo e((($biodata->jenis_kelamin == 'Perempuan')?'selected':'')); ?>>Perempuan</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->jenis_kelamin); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Tanggal Lahir </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->tgl_lahir); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->tgl_lahir); ?>">
                            <div class="d-none input-group m-0">
                                 : &nbsp;<input type="date"class="form-control" name="tgl_lahir" value="<?php echo e($biodata->tgl_lahir); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->tgl_lahir); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Cita Cita </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e(implode(explode(' ', $biodata->cita_cita),'-')); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e(implode(explode(' ', $biodata->cita_cita),'-')); ?>">
                            <?php
                                $ctct = [
                                    'Pegawai Kantoran',
                                    'Programmer',
                                    'Jalan-Jalan Keliling Dunia',
                                    'Photographer',
                                    'Staf Hotel',
                                    'Crew Kapal Pesiar',
                                    'Chef Restoran/Hotel',
                                    'Pemandu Wisata',
                                    'Atlit Esport',
                                    'Desain grafis/ilustrator/animator',
                                    'Ahli IT/Komputer',
                                    'Barista',
                                    'Pramugari/Pramugara'
                                ];
                            ?>
                            <div class="d-none input-group text-left m-0" style="position: relative;">
                                 : &nbsp;<select id="ct" class="custom-select" name="cita_cita">
                                    <?php $__currentLoopData = $ctct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($ct); ?>" <?php echo e((($biodata->cita_cita == $ct)?'selected':'')); ?>><?php echo e($ct); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <option value="other">Lainnya... Sebutkan :</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->cita_cita); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Minat Melanjutkan </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->minat_melanjutkan); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->minat_melanjutkan); ?>">
                            <div class="d-none input-group text-left m-0" style="position: relative;">
                                 : &nbsp;<select class="custom-select" name="minat_melanjutkan">
                                    <option value="Kuliah" <?php echo e((($biodata->minat_melanjutkan == 'Kuliah')?'selected':'')); ?>>Kuliah</option>
                                    <option value="Kerja" <?php echo e((($biodata->minat_melanjutkan == 'Kerja')?'selected':'')); ?>>Kerja</option>
                                    <option value="Wirausaha" <?php echo e((($biodata->minat_melanjutkan == 'Wirausaha')?'selected':'')); ?>>Wirausaha</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->minat_melanjutkan); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Hobi </b><a href="" class="edit-biodata" onclick="editBio('<?php echo e(implode(explode(' ', $biodata->hobi),'-')); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e(implode(explode(' ', $biodata->hobi),'-')); ?>">
                            <?php
                                $hobi = [
                                    'Musik (K-Pop)',
                                    'Olah Raga',
                                    'Esport (Game Online)',
                                    'Youtuber',
                                    'English Club',
                                    'Music',
                                    'Nonton Film (Drakor)',
                                    'Photographer',
                                    'Menggambar'
                                ];
                            ?>
                            <div class="d-none m-0 input-group text-left" style="position: relative;">
                                 : &nbsp;<select id="hb" class="custom-select" name="hobi">
                                    <?php $__currentLoopData = $hobi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hb); ?>" <?php echo e((($biodata->hobi == $hb)?'selected':'')); ?>><?php echo e($hb); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="other">Lainnya... Sebutkan:</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->hobi); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nomor HP </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->no_telp); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->no_telp); ?>">
                            <div class=" d-none input-group"> : &nbsp;<input type="number" class="form-control" name="no_telp" value="<?php echo e($biodata->no_telp); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->no_telp); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            if(!$biodata->email){
                                $getemail = 'email';
                            }else{
                                $getemail = implode(explode('.', implode(explode('@', $biodata->email),'-')),'-');
                            }
                        ?>
                        <div class="col-3"><b>Email </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getemail); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getemail); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="email" class="form-control" name="email" value="<?php echo e($biodata->email); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->email); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            if(!$biodata->facebook){
                                $getfacebook = 'facebook';
                            }
                        ?>
                        <div class="col-3"><b>Akun Facebook </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getfacebook ?? ''); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getfacebook ?? ''); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="facebook" value="<?php echo e($biodata->facebook); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->facebook); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            if(!$biodata->instagram){
                                $getinstagram = 'instagram';
                            }
                        ?>
                        <div class="col-3"><b>Akun Instagram </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getinstagram); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getinstagram); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="instagram" value="<?php echo e($biodata->instagram); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->instagram); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            if(!$biodata->youtube){
                                $getyoutube = 'youtube';
                            }
                        ?>
                        <div class="col-3"><b>Akun Youtube </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getyoutube); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getyoutube); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="youtube" value="<?php echo e($biodata->youtube); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->youtube); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Kelebihan Diri </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->strength); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->strength); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="strength" value="<?php echo e($biodata->strength); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->strength); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Kekurangan Diri </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->weakness); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->weakness); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="weakness" value="<?php echo e($biodata->weakness); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->weakness); ?></p>
                        </div>
                    </div>
                </li>
            </ul>
            <h5 class="text-center mt-5">Biodata Orang Tua</h5>
            <ul class="list-group list-group-flush text-left">
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nama Ayah </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e(implode(explode(' ', $biodata->nama_ayah),'-')); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e(implode(explode(' ', $biodata->nama_ayah),'-')); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="nama_ayah" value="<?php echo e($biodata->nama_ayah); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->nama_ayah); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nomor HP Ayah </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->hp_ayah); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->hp_ayah); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="number" class="form-control" name="hp_ayah" value="<?php echo e($biodata->hp_ayah); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->hp_ayah); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            $dadjob = [
                                'Pegawai Negeri/TNI/POLRI/BUMN/BUMD',
                                'Pegawai Swasta',
                                'Wiraswasta/Pengusaha/Pedagang'
                            ];
                            
                            if(!$biodata->job_ayah){
                                $getjob_ayah = 'job_ayah';
                            }else{
                                $getjob_ayah = implode(explode('/', implode(explode(' ', $biodata->job_ayah),'-')),'-');
                            }
                        ?>
                        <div class="col-3"><b>Pekerjaan Ayah </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getjob_ayah); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getjob_ayah); ?>">
                            <div class="d-none input-group text-left" style="position: relative;">
                                 : &nbsp;<select class="custom-select" name="job_ayah">
                                    <?php $__currentLoopData = $dadjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dj); ?>" <?php echo e((($biodata->job_ayah == $dj)?'selected':'')); ?>><?php echo e($dj); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="other">Lainnya... Sebutkan:</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->job_ayah); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nama Ibu </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e(implode(explode(' ', $biodata->nama_ibu),'-')); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e(implode(explode(' ', $biodata->nama_ibu),'-')); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="text" class="form-control" name="nama_ibu" value="<?php echo e($biodata->nama_ibu); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->nama_ibu); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <div class="col-3"><b>Nomor HP Ibu </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($biodata->hp_ibu); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($biodata->hp_ibu); ?>">
                            <div class="d-none input-group"> : &nbsp;<input type="number" class="form-control" name="hp_ibu" value="<?php echo e($biodata->hp_ibu); ?>">
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->hp_ibu); ?></p>
                        </div>
                    </div>
                </li>
                <li class="list-group-item">
                    <div class="row">
                        <?php
                            $momjob = [
                                'Ibu Rumah Tangga',
                                'Pegawai Negeri/TNI/POLRI/BUMN/BUMD',
                                'Pegawai Swasta',
                                'Wiraswasta/Pengusaha/Pedagang'
                            ];
                            
                            if(!$biodata->job_ibu){
                                $getjob_ibu = 'job_ibu';
                            }else{
                                $getjob_ibu = implode(explode('/', implode(explode(' ', $biodata->job_ibu),'-')),'-');
                            }
                        ?>
                        <div class="col-3"><b>Pekerjaan Ibu </b><a href="" class="ml-2 edit-biodata" onclick="editBio('<?php echo e($getjob_ibu); ?>')"><i class="fas fa-edit"></i></a></div>
                        <div class="col-9 biodata get-<?php echo e($getjob_ibu); ?>">
                            <div class="d-none input-group text-left" style="position: relative;">
                                 : &nbsp;<select class="custom-select" name="job_ibu">
                                    <?php $__currentLoopData = $momjob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mj); ?>" <?php echo e((($biodata->job_ibu == $mj)?'selected':'')); ?>><?php echo e($mj); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <option value="other">Lainnya... Sebutkan:</option>
                                </select>
                                <button class="btn btn-md btn-primary m-0 px-3" type="submit">edit</button>
                            </div>
                            <p class="m-0"> : <?php echo e($biodata->job_ibu); ?></p>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_addon'); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $(".edit-biodata").on("click", function(e){
           e.preventDefault(); 
        });
    });
    
    function editBio(edit_bio_ret){
        $('.biodata.get-'+edit_bio_ret+" div").toggleClass('d-none');
        $('.biodata.get-'+edit_bio_ret+" p").toggleClass('d-none');
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u5777787/public_html/tespotensidiri/resources/views/users/general/biodata_read.blade.php ENDPATH**/ ?>